Promise.all([
  d3.json('https://raw.githubusercontent.com/holtzy/D3-graph-gallery/master/DATA/world.geojson'),
  d3.csv('data/per-capita-energy.csv'),
  d3.csv('data/energy-consumption-by-source-and-country.csv')
]).then(data => {
  const geoData      = data[0];
  const perCapitaCsv = data[1];
  const totalCsv     = data[2];

  // ── Energy type lists ──────────────────────────────────────────────────
  const energyTypesPC    = perCapitaCsv.columns.slice(3);   // kWh/capita columns
  const energyTypesTotal = totalCsv.columns.slice(3);       // TWh columns

  // ── Helpers ────────────────────────────────────────────────────────────
  const normalize = s => s ? String(s).toLowerCase().replace(/[^a-z0-9]/g, '') : '';

  // Build lookup for choropleth maps
  const energyLookup = { byName: {}, byCode: {}, byNorm: {}, rows: perCapitaCsv };
  perCapitaCsv.forEach(d => {
    d.Total = energyTypesPC.reduce((sum, t) => sum + (+d[t] || 0), 0);
    if (d.Entity) energyLookup.byName[d.Entity]  = d;
    if (d.Code)   energyLookup.byCode[d.Code]    = d;
    energyLookup.byNorm[normalize(d.Entity)]     = d;
  });

  // ── VIS 1 — Stacked bar chart of total energy by country ───────────────
  // Filter out rows with no data
  const vis1Data = totalCsv.filter(d =>
    energyTypesTotal.some(k => +d[k] > 0)
  );

  new Barchart({
    parentElement:    '#vis1-container',
    containerWidth:   900,
    containerHeight:  vis1Data.length * 20 + 60,
    margin:           { top: 40, right: 170, bottom: 40, left: 160 },
    isStacked:        true,
    energyTypes:      energyTypesTotal,
    unit:             'TWh'
  }, vis1Data);

  // ── VIS 2 — Single-type bar chart (total TWh) with dropdown ───────────
  const vis2Data = totalCsv.filter(d =>
    energyTypesTotal.some(k => +d[k] > 0)
  );

  const vis2Chart = new Barchart({
    parentElement:    '#vis2-container',
    containerWidth:   900,
    containerHeight:  vis2Data.length * 20 + 60,
    margin:           { top: 40, right: 30, bottom: 40, left: 160 },
    isStacked:        false,
    energyTypes:      energyTypesTotal,
    unit:             'TWh'
  }, vis2Data);

  // Populate vis2 dropdown and wire it up
  const sel2 = d3.select('#energy-select3');
  sel2.selectAll('option')
    .data(energyTypesTotal)
    .join('option')
    .attr('value', d => d)
    .text(d => d);

  vis2Chart.updateVis(energyTypesTotal[0]);

  sel2.on('change', function () {
    vis2Chart.updateVis(this.value);
  });

  // ── VIS 2.5 — Per-capita bar chart with dropdown ───────────────────────
  const vis25Data = perCapitaCsv.filter(d =>
    energyTypesPC.some(k => +d[k] > 0)
  );

  const vis25Chart = new Barchart({
    parentElement:    '#vis25-container',
    containerWidth:   900,
    containerHeight:  vis25Data.length * 20 + 60,
    margin:           { top: 40, right: 30, bottom: 40, left: 160 },
    isStacked:        false,
    energyTypes:      energyTypesPC,
    unit:             'kWh/capita'
  }, vis25Data);

  const sel25 = d3.select('#energy-select25');
  sel25.selectAll('option')
    .data(energyTypesPC)
    .join('option')
    .attr('value', d => d)
    .text(d => d);

  vis25Chart.updateVis(energyTypesPC[0]);

  sel25.on('change', function () {
    vis25Chart.updateVis(this.value);
  });

  // ── VIS 3 — Scatterplot: total vs per-capita ────────────────────────────
  new Scatterplot(
    { parentElement: '#vis3-container' },
    totalCsv,
    perCapitaCsv
  );

  // ── Choropleth maps (tabs 4 & 5) ──────────────────────────────────────
  const typesWithTotal = ['Total', ...energyTypesPC];

  const sel2map = d3.select('#energy-select2');
  sel2map.selectAll('option')
    .data(typesWithTotal)
    .join('option')
    .attr('value', d => d)
    .text(d => d);

  const totalMap = new ChoroplethMap({
    parentElement:    '#map2',
    containerWidth:   900,
    containerHeight:  600,
    energyTypes:      typesWithTotal
  }, geoData, energyLookup);

  totalMap.setEnergyType('Total');
  sel2map.on('change', function () { totalMap.setEnergyType(this.value); });

  const selMap = d3.select('#energy-select');
  selMap.selectAll('option')
    .data(energyTypesPC)
    .join('option')
    .attr('value', d => d)
    .text(d => d);

  const choroplethMap = new ChoroplethMap({
    parentElement:   '#map',
    containerWidth:  900,
    containerHeight: 600,
    energyTypes:     energyTypesPC
  }, geoData, energyLookup);

  choroplethMap.setEnergyType(energyTypesPC[0]);
  selMap.on('change', function () { choroplethMap.setEnergyType(this.value); });

}).catch(error => console.error(error));
