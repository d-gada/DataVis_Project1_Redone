class ChoroplethMap {

  /**
   * Class constructor with basic configuration
   * @param {Object} _config configuration object
   * @param {Object} _geoData geojson data for world
   * @param {Object} _energyData map from country name to row values
   */
  constructor(_config, _geoData, _energyData) {
    this.config = {
      parentElement: _config.parentElement,
      containerWidth: _config.containerWidth || 500,
      containerHeight: _config.containerHeight || 400,
      margin: _config.margin || { top: 0, right: 0, bottom: 0, left: 0 },
      tooltipPadding: 10,
      legendBottom: 50,
      legendLeft: 50,
      legendRectHeight: 12,
      legendRectWidth: 150
    }
    this.geoData = _geoData;
    this.energyData = _energyData;
    // list of all possible energy types for palette selection
    this.config.energyTypes = _config.energyTypes || [];
    this.selectedType = null;
    this.initVis();
  }

  /**
   * We initialize scales/axes and append static elements, such as axis titles.
   */
  initVis() {
    let vis = this;

    // Calculate inner chart size. Margin specifies the space around the actual chart.
    vis.width = vis.config.containerWidth - vis.config.margin.left - vis.config.margin.right;
    vis.height = vis.config.containerHeight - vis.config.margin.top - vis.config.margin.bottom;

    // Define size of SVG drawing area
    vis.svg = d3.select(vis.config.parentElement).append('svg')
      .attr('width', vis.config.containerWidth)
      .attr('height', vis.config.containerHeight);

    // Append group element that will contain our actual chart 
    // and position it according to the given margin config
    vis.chart = vis.svg.append('g')
      .attr('transform', `translate(${vis.config.margin.left},${vis.config.margin.top})`);

    // Initialize projection and path generator
    vis.projection = d3.geoMercator();
    vis.geoPath = d3.geoPath().projection(vis.projection);

    vis.colorScale = d3.scaleLinear()
      .range(['#cfe2f2', '#0d306b'])
      .interpolate(d3.interpolateHcl);

    // energy value that will be used for coloring (added in updateVis)
    vis.currentValues = [];


    // Initialize gradient that we will later use for the legend
    vis.linearGradient = vis.svg.append('defs').append('linearGradient')
      .attr("id", "legend-gradient");

    // Append legend
    vis.legend = vis.chart.append('g')
      .attr('class', 'legend')
      .attr('transform', `translate(${vis.config.legendLeft},${vis.height - vis.config.legendBottom})`);

    vis.legendRect = vis.legend.append('rect')
      .attr('width', vis.config.legendRectWidth)
      .attr('height', vis.config.legendRectHeight);

    vis.legendTitle = vis.legend.append('text')
      .attr('class', 'legend-title')
      .attr('dy', '.35em')
      .attr('y', -10)
      .text('')

    vis.updateVis();
  }

  // updateVis is called any time the selectedType or data changes
  updateVis() {
    let vis = this;

    // compute energy value for each feature and store on properties
    vis.currentValues = vis.geoData.features.map(f => {
      // robust lookup: try exact name, ISO codes, id, and normalized name
      const getProp = p => (f.properties && f.properties[p]) || f[p] || null;
      const name = getProp('name') || getProp('ADMIN') || getProp('NAME') || '';
      const isoA3 = getProp('iso_a3') || getProp('ISO_A3') || getProp('iso3');
      const isoA2 = getProp('iso_a2') || getProp('ISO_A2') || getProp('iso2');

      const normalize = s => s ? String(s).toLowerCase().replace(/[^a-z0-9]/g, '') : '';
      const normName = normalize(name);

      let row = null;
      if (vis.energyData) {
        // if energyData is a lookup object with multiple maps
        if (vis.energyData.byName || vis.energyData.byCode || vis.energyData.byNorm) {
          // try common keys: exact Entity name, ISO codes, feature id, normalized name
          row = (vis.energyData.byName && vis.energyData.byName[name])
            || (isoA3 && vis.energyData.byCode && vis.energyData.byCode[isoA3])
            || (isoA2 && vis.energyData.byCode && vis.energyData.byCode[isoA2])
            || (f.id && vis.energyData.byCode && vis.energyData.byCode[f.id])
            || (vis.energyData.byName && vis.energyData.byName[f.id])
            || (vis.energyData.byNorm && vis.energyData.byNorm[normName])
            || null;
        } else {
          // fallback: energyData might be a simple map keyed by name or code
          row = vis.energyData[name] || vis.energyData[f.id] || vis.energyData[normName] || vis.energyData[String(name).toUpperCase()] || null;
        }
      }

      // If still not found, try fuzzy matching against available CSV rows (includes checks)
      if (!row && vis.energyData && vis.energyData.rows && Array.isArray(vis.energyData.rows)) {
        const rows = vis.energyData.rows;
        for (let i = 0; i < rows.length; i++) {
          const r = rows[i];
          const rnorm = normalize(r.Entity || r.EntityName || '');
          if (!rnorm) continue;
          if (rnorm === normName || rnorm.includes(normName) || normName.includes(rnorm)) {
            row = r;
            break;
          }
        }
      }

      // attach lookup diagnostics to the feature for debugging
      if (!row) {
        f.properties._lookupAttempt = { name, isoA3, isoA2, normName };
      }

      let val = null;
      if (row != null) {
        if (typeof row === 'number') {
          val = row;
        } else if (vis.selectedType) {
          val = +row[vis.selectedType];
        }
      }
      f.properties.energy = val;
      return val;
    }).filter(v => v != null);

    const valueExtent = d3.extent(vis.currentValues);

    // if no valid values yet, skip domain update and legend
    if (valueExtent[0] == null) {
      vis.legendStops = [];
    } else {
      // Update color scale
      vis.colorScale.domain(valueExtent);

      // Define begin and end of the color gradient (legend)
      vis.legendStops = [
        { color: '#cfe2f2', value: valueExtent[0], offset: 0 },
        { color: '#0d306b', value: valueExtent[1], offset: 100 },
      ];
    }

    // update legend title
    vis.legendTitle.text(vis.selectedType || '');

    // finally re‑render the map with the new scale/data
    vis.renderVis();
  }

  // set the current energy type and refresh the map
  setEnergyType(type) {
    this.selectedType = type;

    // change color scheme based on type index
    if (this.config.energyTypes.length > 0) {
      const idx = this.config.energyTypes.indexOf(type);
      const n = this.config.energyTypes.length;
      const t = idx / Math.max(1, n - 1);
      const startColor = d3.interpolateRainbow(t);
      const endColor = d3.interpolateRainbow((t + 0.2) % 1);
      this.colorScale.range([startColor, endColor]);
    }

    this.updateVis();
  }


  renderVis() {
    let vis = this;

    // GeoJSON data is already provided in geoData
    const countries = vis.geoData;

    // Defines the scale of the projection so that the geometry fits within the SVG area
    vis.projection.fitSize([vis.width, vis.height], countries);

    // Append or update world map
    const countryPath = vis.chart.selectAll('.country')
      .data(countries.features)
      .join('path')
      .attr('class', 'country')
      .attr('d', vis.geoPath)
      .attr('fill', d => {
        const val = d.properties.energy;
        if (val != null) {
          return vis.colorScale(val);
        } else {
          return 'url(#lightstripe)';
        }
      });

    countryPath
      .on('mousemove', (event, d) => {
        const val = d.properties.energy;
        const info = val != null
          ? `<strong>${Math.round(val * 10) / 10}</strong> ${vis.selectedType}`
          : 'No data available';
        d3.select('#tooltip')
          .style('display', 'block')
          .style('left', (event.pageX + vis.config.tooltipPadding) + 'px')
          .style('top', (event.pageY + vis.config.tooltipPadding) + 'px')
          .html(`
              <div class="tooltip-title">${d.properties.name}</div>
              <div>${info}</div>
            `);
      })
      .on('mouseleave', () => {
        d3.select('#tooltip').style('display', 'none');
      });

    // Add legend labels
    vis.legend.selectAll('.legend-label')
      .data(vis.legendStops)
      .join('text')
      .attr('class', 'legend-label')
      .attr('text-anchor', 'middle')
      .attr('dy', '.35em')
      .attr('y', 20)
      .attr('x', (d, index) => {
        return index == 0 ? 0 : vis.config.legendRectWidth;
      })
      .text(d => Math.round(d.value * 10) / 10);

    // Update gradient for legend
    vis.linearGradient.selectAll('stop')
      .data(vis.legendStops)
      .join('stop')
      .attr('offset', d => d.offset)
      .attr('stop-color', d => d.color);

    vis.legendRect.attr('fill', 'url(#legend-gradient)');
  }
}
